/* ============================================================
   /api/payment-check
   Verifica o status de um pagamento na InfinitePay.

   Estrutura preparada para validação futura: hoje a página
   /confirmado não bloqueia o acesso, mas este endpoint já
   permite confirmar um pagamento antes de liberar benefícios
   (ex.: link do grupo, material, área de membros).

   Uso (GET):
   /api/payment-check?transaction_nsu=...&order_nsu=...&slug=...
   ============================================================ */

const HANDLE = process.env.INFINITEPAY_HANDLE || 'gps-mentoria';
const PAYMENT_CHECK_ENDPOINT =
  process.env.INFINITEPAY_PAYMENT_CHECK_URL ||
  'https://api.infinitepay.io/invoices/public/checkout/payment_check';
const TIMEOUT_MS = 12000;

/** Sanitiza um parâmetro vindo do navegador (nunca confiar no cliente). */
function clean(value, max = 128) {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, max);
}

module.exports = async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ error: 'Método não permitido.' });
  }

  const transaction_nsu = clean(req.query.transaction_nsu);
  const order_nsu = clean(req.query.order_nsu);
  const slug = clean(req.query.slug);

  if (!transaction_nsu && !slug) {
    return res.status(400).json({ error: 'Parâmetros insuficientes.' });
  }

  const payload = {
    handle: HANDLE,
    transaction_nsu,
    external_order_nsu: order_nsu,
    slug
  };

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

    const response = await fetch(PAYMENT_CHECK_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timeout);

    if (!response.ok) {
      const body = await response.text().catch(() => '');
      console.error('payment-check HTTP', response.status, body.slice(0, 500));
      return res.status(502).json({ paid: false, error: 'Não foi possível verificar o pagamento.' });
    }

    const data = await response.json().catch(() => null);

    // Normaliza a resposta em um formato simples para o front-end
    const paid = Boolean(data && (data.success === true || data.paid === true));

    return res.status(200).json({ paid });
  } catch (err) {
    console.error('payment-check error:', err && err.message);
    return res.status(502).json({ paid: false, error: 'Não foi possível verificar o pagamento.' });
  }
};
