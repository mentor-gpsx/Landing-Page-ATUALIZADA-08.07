/* ============================================================
   /api/create-checkout
   Cria um Checkout Externo na InfinitePay e devolve { url }
   ============================================================ */

/* ---------- Configuração (fácil de alterar) ---------- */
const HANDLE = process.env.INFINITEPAY_HANDLE || 'gps-mentoria';
const PRICE_CENTS = parseInt(process.env.PRICE_CENTS || '2700', 10); // R$27,00
const DESCRIPTION = process.env.PRODUCT_DESCRIPTION || 'Workshop Formação de Gestores';
const INFINITEPAY_ENDPOINT = 'https://api.checkout.infinitepay.io/links';
const TIMEOUT_MS = 12000;

/**
 * Monta a URL de redirecionamento pós-pagamento a partir do host da
 * requisição (funciona em preview e produção da Vercel sem configurar nada).
 * Pode ser fixada via env BASE_URL, ex.: https://meudominio.com
 */
function buildRedirectUrl(req) {
  const base =
    process.env.BASE_URL ||
    `https://${req.headers['x-forwarded-host'] || req.headers.host}`;
  return `${base.replace(/\/$/, '')}/confirmado`;
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Método não permitido.' });
  }

  const payload = {
    handle: HANDLE,
    redirect_url: buildRedirectUrl(req),
    items: [
      {
        quantity: 1,
        price: PRICE_CENTS,
        description: DESCRIPTION
      }
    ]
  };

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

    const response = await fetch(INFINITEPAY_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timeout);

    if (!response.ok) {
      // Log interno para debug na Vercel — nunca exposto ao usuário
      const body = await response.text().catch(() => '');
      console.error('InfinitePay HTTP', response.status, body.slice(0, 500));
      return res.status(502).json({ error: 'Falha ao criar o checkout.' });
    }

    const data = await response.json().catch(() => null);

    // A API pode retornar a URL em campos diferentes conforme a versão
    const url = data && (data.url || data.link || data.checkout_url);

    if (!url || typeof url !== 'string' || !url.startsWith('https://')) {
      console.error('InfinitePay: resposta sem URL válida', JSON.stringify(data).slice(0, 500));
      return res.status(502).json({ error: 'Falha ao criar o checkout.' });
    }

    return res.status(200).json({ url });
  } catch (err) {
    console.error('create-checkout error:', err && err.message);
    return res.status(502).json({ error: 'Falha ao criar o checkout.' });
  }
};
